# PlantMe Icons v1

Biblioteca original com 200 símbolos e duas variantes vetoriais: Stroke Rounded e Solid Rounded. Total de 400 SVGs.

## Estrutura
- `svg/stroke-rounded`: 200 SVGs com traço 1,8 px, pontas e junções arredondadas.
- `svg/solid-rounded`: 200 SVGs preenchidos, com detalhes auxiliares vetoriais.
- `manifest.json`: catálogo, categorias e tokens.
- `catalog.svg`: prancha completa.
- `index.html`: navegador local com busca e filtros.

## Figma
Arraste as duas pastas para o Figma. Cada SVG possui viewBox 24 × 24 e cores explícitas editáveis. Organize cada par como variantes `Style=Stroke Rounded` e `Style=Solid Rounded`.

## Direção visual
A linguagem usa curvas contínuas, terminações arredondadas e proporções suaves. Os desenhos são originais e não reutilizam arquivos da Solar, Hugeicons ou 99.
